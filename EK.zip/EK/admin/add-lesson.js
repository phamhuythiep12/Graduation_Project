const imageUpload = document.getElementById("imageUpload");
const imagePreview = document.getElementById("imagePreview");
const videoLink = document.getElementById("videoLink");
const flashcardContainer = document.getElementById("flashcardContainer");
const addFlashcardBtn = document.getElementById("addFlashcardBtn");
const saveLessonBtn = document.getElementById("saveLessonBtn");

imageUpload.addEventListener("change", function() {
	const file = this.files[0];
	if (file) {
		const reader = new FileReader();
		reader.addEventListener("load", function() {
			imagePreview.style.backgroundImage = `url(${this.result})`;
		});
		reader.readAsDataURL(file);
	}
});

addFlashcardBtn.addEventListener("click", function() {
	const flashcard = document.createElement("div");
	flashcard.classList.add("flashcard");
	flashcard.innerHTML = `
        <div class="front">
            <h3>Front of Flashcard</h3>
            <input type="file" class="frontTextarea" name="front[]">
        </div>
        <div class="back">
            <h3>Back of Flashcard</h3>
            <textarea class="backTextarea" name="back[]"></textarea>
        </div>
	`;
	flashcardContainer.appendChild(flashcard);
});

saveLessonBtn.addEventListener("click", function() {
	const formData = new FormData(document.getElementById("lessonForm"));
	
	// Do whatever you want with the form data here, like sending it to a server or processing it with JavaScript.
	for (let pair of formData.entries()) {
		console.log(pair[0] + ": " + pair[1]);
	}

    //window.location.href= "manage-posts.html";
});
